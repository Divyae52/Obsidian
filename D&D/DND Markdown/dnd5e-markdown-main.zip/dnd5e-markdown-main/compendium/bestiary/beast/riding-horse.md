---
obsidianUIMode: preview
cssclasses: json5e-monster
tags:
- compendium/src/5e/mm
- monster/environment/grassland
- monster/environment/urban
- monster/size/large
- monster/type/beast
aliases: ["Riding Horse"]
---
# Riding Horse
*Source: SRD / Basic Rules*  

```ad-statblock
title: Riding Horse
![](compendium/bestiary/beast/token/riding-horse.png#token)
*Large beast, Unaligned*

- **Armor Class** 10 
- **Hit Points** 13 (`2d10 + 2`)
- **Speed** 60 ft.

|STR|DEX|CON|INT|WIS|CHA|
|:---:|:---:|:---:|:---:|:---:|:---:|
|16 (+3)|10 (+0)|12 (+1)| 2 (-4)|11 (+0)| 7 (-2)|

- **Proficiency Bonus** +2
- **Saving Throws** ⏤
- **Skills** ⏤
- **Senses** passive Perception 10

- **Languages** —
- **Challenge** 1/4

## Actions

***Hooves.*** *Melee Weapon Attack:* +5 to hit, reach 5 ft., one target. *Hit:* 8 (`2d4 + 3`) bludgeoning damage.
```
^statblock

## Environment

grassland, urban