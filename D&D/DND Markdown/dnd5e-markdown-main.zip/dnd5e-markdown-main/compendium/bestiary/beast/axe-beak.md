---
obsidianUIMode: preview
cssclasses: json5e-monster
tags:
- compendium/src/5e/mm
- monster/environment/grassland
- monster/environment/hill
- monster/size/large
- monster/type/beast
aliases: ["Axe Beak"]
---
# Axe Beak
*Source: SRD / Basic Rules*  

```ad-statblock
title: Axe Beak
![](compendium/bestiary/beast/token/axe-beak.png#token)
*Large beast, Unaligned*

- **Armor Class** 11 
- **Hit Points** 19 (`3d10 + 3`)
- **Speed** 50 ft.

|STR|DEX|CON|INT|WIS|CHA|
|:---:|:---:|:---:|:---:|:---:|:---:|
|14 (+2)|12 (+1)|12 (+1)| 2 (-4)|10 (+0)| 5 (-3)|

- **Proficiency Bonus** +2
- **Saving Throws** ⏤
- **Skills** ⏤
- **Senses** passive Perception 10

- **Languages** —
- **Challenge** 1/4

## Actions

***Beak.*** *Melee Weapon Attack:* +4 to hit, reach 5 ft., one target. *Hit:* 6 (`1d8 + 2`) slashing damage.
```
^statblock

## Environment

grassland, hill