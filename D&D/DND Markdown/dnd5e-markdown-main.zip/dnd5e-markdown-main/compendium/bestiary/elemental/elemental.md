---
obsidianUIMode: preview
cssclasses: json5e-note
---
# Index of Elemental

- [Air Elemental](air-elemental.md)
- [Azer](azer.md)
- [Djinni](djinni.md)
- [Dust Mephit](dust-mephit.md)
- [Earth Elemental](earth-elemental.md)
- [Efreeti](efreeti.md)
- [Fire Elemental](fire-elemental.md)
- [Gargoyle](gargoyle.md)
- [Ice Mephit](ice-mephit.md)
- [Invisible Stalker](invisible-stalker.md)
- [Magma Mephit](magma-mephit.md)
- [Magmin](magmin.md)
- [Salamander](salamander.md)
- [Steam Mephit](steam-mephit.md)
- [Water Elemental](water-elemental.md)
- [Xorn](xorn.md)
