---
obsidianUIMode: preview
cssclasses: json5e-note
---
# Index of Plant

- [Awakened Shrub](awakened-shrub.md)
- [Awakened Tree](awakened-tree.md)
- [Shambling Mound](shambling-mound.md)
- [Shrieker](shrieker.md)
- [Treant](treant.md)
- [Violet Fungus](violet-fungus.md)
