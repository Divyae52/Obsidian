---
obsidianUIMode: preview
cssclasses: json5e-note
---
# Index of Undead

- [Avatar of Death (DMG)](avatar-of-death-dmg.md)
- [Ghast](ghast.md)
- [Ghost](ghost.md)
- [Ghoul](ghoul.md)
- [Lich](lich.md)
- [Minotaur Skeleton](minotaur-skeleton.md)
- [Mummy Lord](mummy-lord.md)
- [Mummy](mummy.md)
- [Ogre Zombie](ogre-zombie.md)
- [Shadow](shadow.md)
- [Skeleton](skeleton.md)
- [Specter](specter.md)
- [Vampire Spawn](vampire-spawn.md)
- [Vampire](vampire.md)
- [Warhorse Skeleton](warhorse-skeleton.md)
- [Wight](wight.md)
- [Will-o'-Wisp](will-o-wisp.md)
- [Wraith](wraith.md)
- [Zombie](zombie.md)
