---
obsidianUIMode: preview
cssclasses: json5e-note
---
# Index of Construct

- [Animated Armor](animated-armor.md)
- [Clay Golem](clay-golem.md)
- [Flesh Golem](flesh-golem.md)
- [Flying Sword](flying-sword.md)
- [Homunculus](homunculus.md)
- [Iron Golem](iron-golem.md)
- [Rug of Smothering](rug-of-smothering.md)
- [Shield Guardian](shield-guardian.md)
- [Stone Golem](stone-golem.md)
