---
obsidianUIMode: preview
cssclasses: json5e-note
---
# Index of Aberration

- [Aboleth](aboleth.md)
- [Chuul](chuul.md)
- [Cloaker](cloaker.md)
- [Gibbering Mouther](gibbering-mouther.md)
- [Otyugh](otyugh.md)
