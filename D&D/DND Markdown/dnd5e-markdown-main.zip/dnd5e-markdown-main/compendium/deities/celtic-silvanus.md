---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/nature
aliases: ["Silvanus"]
---
# Silvanus
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral
- **Domains**: Nature
- **Pantheon**: Celtic
- **Symbol**: Summer oak tree