---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/life
aliases: ["Hestia"]
---
# Hestia
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Good
- **Domains**: Life
- **Pantheon**: Greek
- **Symbol**: Hearth