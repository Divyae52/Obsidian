---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/war
aliases: ["Ares"]
---
# Ares
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Evil
- **Domains**: War
- **Pantheon**: Greek
- **Symbol**: Spear