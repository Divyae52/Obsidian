---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/trickery
aliases: ["Tyche"]
---
# Tyche
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral
- **Domains**: Trickery
- **Pantheon**: Greek
- **Symbol**: Red pentagram