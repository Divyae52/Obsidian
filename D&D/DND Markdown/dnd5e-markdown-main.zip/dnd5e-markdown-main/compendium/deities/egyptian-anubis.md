---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/death
- domain/grave
- domain/order
aliases: ["Anubis"]
---
# Anubis
*Source: SRD / Basic Rules* 

- **Alignment**: Lawful Neutral
- **Domains**: Death, Grave, Order
- **Pantheon**: Egyptian
- **Symbol**: Black jackal