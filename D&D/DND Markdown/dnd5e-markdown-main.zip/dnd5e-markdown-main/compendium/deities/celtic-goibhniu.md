---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/forge
- domain/knowledge
- domain/life
aliases: ["Goibhniu"]
---
# Goibhniu
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Good
- **Domains**: Forge, Knowledge, Life
- **Pantheon**: Celtic
- **Symbol**: Giant mallet over sword