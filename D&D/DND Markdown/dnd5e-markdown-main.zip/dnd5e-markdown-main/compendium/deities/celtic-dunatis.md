---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/nature
aliases: ["Dunatis"]
---
# Dunatis
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral
- **Domains**: Nature
- **Pantheon**: Celtic
- **Symbol**: Red sun-capped mountain peak