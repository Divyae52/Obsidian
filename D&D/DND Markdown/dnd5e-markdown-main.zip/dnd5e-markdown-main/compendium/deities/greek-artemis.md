---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/life
- domain/nature
aliases: ["Artemis"]
---
# Artemis
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Good
- **Domains**: Life, Nature
- **Pantheon**: Greek
- **Symbol**: Bow and arrow on lunar disk