---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/nature
- domain/tempest
aliases: ["Sobek"]
---
# Sobek
*Source: SRD / Basic Rules* 

- **Alignment**: Lawful Evil
- **Domains**: Nature, Tempest
- **Pantheon**: Egyptian
- **Symbol**: Crocodile head with horns and plumes