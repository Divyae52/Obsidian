---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/death
- domain/tempest
- domain/trickery
aliases: ["Set"]
---
# Set
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Evil
- **Domains**: Death, Tempest, Trickery
- **Pantheon**: Egyptian
- **Symbol**: Coiled cobra