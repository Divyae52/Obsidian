---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/grave
- domain/life
- domain/nature
aliases: ["Osiris"]
---
# Osiris
*Source: SRD / Basic Rules* 

- **Alignment**: Lawful Good
- **Domains**: Grave, Life, Nature
- **Pantheon**: Egyptian
- **Symbol**: Crook and flail