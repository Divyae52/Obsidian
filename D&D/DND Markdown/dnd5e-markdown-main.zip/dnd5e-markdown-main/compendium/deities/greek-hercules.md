---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/tempest
- domain/war
aliases: ["Hercules"]
---
# Hercules
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Good
- **Domains**: Tempest, War
- **Pantheon**: Greek
- **Symbol**: Lion's head