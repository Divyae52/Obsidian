---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/tempest
aliases: ["Zeus"]
---
# Zeus
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral
- **Domains**: Tempest
- **Pantheon**: Greek
- **Symbol**: Fist full of lightning bolts