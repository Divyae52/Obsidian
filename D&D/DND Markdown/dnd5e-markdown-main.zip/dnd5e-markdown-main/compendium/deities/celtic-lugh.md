---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/knowledge
- domain/life
aliases: ["Lugh"]
---
# Lugh
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Neutral
- **Domains**: Knowledge, Life
- **Pantheon**: Celtic
- **Symbol**: Pair of long hands