---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/death
aliases: ["Nephthys"]
---
# Nephthys
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Good
- **Domains**: Death
- **Pantheon**: Egyptian
- **Symbol**: Horns around a lunar disk