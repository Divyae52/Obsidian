---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/light
aliases: ["Aphrodite"]
---
# Aphrodite
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Good
- **Domains**: Light
- **Pantheon**: Greek
- **Symbol**: Sea shell