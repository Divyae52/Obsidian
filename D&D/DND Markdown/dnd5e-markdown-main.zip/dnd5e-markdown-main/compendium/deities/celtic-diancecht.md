---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/life
aliases: ["Diancecht"]
---
# Diancecht
*Source: SRD / Basic Rules* 

- **Alignment**: Lawful Good
- **Domains**: Life
- **Pantheon**: Celtic
- **Symbol**: Crossed oak and mistletoe branches