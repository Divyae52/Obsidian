---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/knowledge
- domain/order
- domain/war
aliases: ["Athena"]
---
# Athena
*Source: SRD / Basic Rules* 

- **Alignment**: Lawful Good
- **Domains**: Knowledge, War, Order
- **Pantheon**: Greek
- **Symbol**: Owl