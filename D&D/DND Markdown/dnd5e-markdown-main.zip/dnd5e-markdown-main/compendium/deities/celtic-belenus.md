---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/light
aliases: ["Belenus"]
---
# Belenus
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Good
- **Domains**: Light
- **Pantheon**: Celtic
- **Symbol**: Solar disk and standing stones