---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/trickery
aliases: ["Hermes"]
---
# Hermes
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Good
- **Domains**: Trickery
- **Pantheon**: Greek
- **Symbol**: Caduceus (winged staff and serpents)