---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/arcana
- domain/knowledge
- domain/life
aliases: ["Isis"]
---
# Isis
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Good
- **Domains**: Knowledge, Life, Arcana
- **Pantheon**: Egyptian
- **Symbol**: Ankh and star