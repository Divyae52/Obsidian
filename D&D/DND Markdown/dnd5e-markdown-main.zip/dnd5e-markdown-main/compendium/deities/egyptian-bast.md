---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/war
aliases: ["Bast"]
---
# Bast
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Good
- **Domains**: War
- **Pantheon**: Egyptian
- **Symbol**: Cat