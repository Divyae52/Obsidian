---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/war
aliases: ["Morrigan"]
---
# Morrigan
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Evil
- **Domains**: War
- **Pantheon**: Celtic
- **Symbol**: Two crossed spears