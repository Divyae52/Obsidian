---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/life
aliases: ["Dionysus"]
---
# Dionysus
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Neutral
- **Domains**: Life
- **Pantheon**: Greek
- **Symbol**: Thyrsus (staff tipped with pine cone)