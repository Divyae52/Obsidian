---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/forge
- domain/knowledge
aliases: ["Hephaestus"]
---
# Hephaestus
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Good
- **Domains**: Forge, Knowledge
- **Pantheon**: Greek
- **Symbol**: Hammer and anvil