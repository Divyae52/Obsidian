---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/order
- domain/war
aliases: ["Nuada"]
---
# Nuada
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral
- **Domains**: War, Order
- **Pantheon**: Celtic
- **Symbol**: Silver hand on black background