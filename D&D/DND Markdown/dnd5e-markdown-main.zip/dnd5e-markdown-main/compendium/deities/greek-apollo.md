---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/knowledge
- domain/life
- domain/light
aliases: ["Apollo"]
---
# Apollo
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Good
- **Domains**: Knowledge, Life, Light
- **Pantheon**: Greek
- **Symbol**: Lyre