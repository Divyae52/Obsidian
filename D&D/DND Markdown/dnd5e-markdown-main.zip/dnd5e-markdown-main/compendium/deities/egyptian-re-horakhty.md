---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/life
- domain/light
aliases: ["Re-Horakhty"]
---
# Re-Horakhty
*Source: SRD / Basic Rules* 

- **Alignment**: Lawful Good
- **Domains**: Life, Light
- **Pantheon**: Egyptian
- **Symbol**: Solar disk encircled by serpent