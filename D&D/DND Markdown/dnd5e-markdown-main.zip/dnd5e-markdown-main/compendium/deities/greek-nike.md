---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/war
aliases: ["Nike"]
---
# Nike
*Source: SRD / Basic Rules* 

- **Alignment**: Lawful Neutral
- **Domains**: War
- **Pantheon**: Greek
- **Symbol**: Winged woman