---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/nature
aliases: ["Pan"]
---
# Pan
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Neutral
- **Domains**: Nature
- **Pantheon**: Greek
- **Symbol**: Syrinx (pan pipes)