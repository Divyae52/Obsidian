---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/nature
- domain/tempest
aliases: ["Manannan mac Lir"]
---
# Manannan mac Lir
*Source: SRD / Basic Rules* 

- **Alignment**: Lawful Neutral
- **Domains**: Nature, Tempest
- **Pantheon**: Celtic
- **Symbol**: Wave of white water on green