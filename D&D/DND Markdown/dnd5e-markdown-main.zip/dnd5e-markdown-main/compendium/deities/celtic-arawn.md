---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/death
- domain/life
aliases: ["Arawn"]
---
# Arawn
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Evil
- **Domains**: Life, Death
- **Pantheon**: Celtic
- **Symbol**: Black star on gray background