---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/trickery
aliases: ["Hera"]
---
# Hera
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Neutral
- **Domains**: Trickery
- **Pantheon**: Greek
- **Symbol**: Fan of peacock feathers