---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/knowledge
aliases: ["Imhotep"]
---
# Imhotep
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Good
- **Domains**: Knowledge
- **Pantheon**: Egyptian
- **Symbol**: Step pyramid