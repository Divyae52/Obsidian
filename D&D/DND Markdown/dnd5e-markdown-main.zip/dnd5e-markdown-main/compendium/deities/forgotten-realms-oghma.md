---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/forgotten-realms
- domain/knowledge
aliases: ["Oghma"]
---
# Oghma
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral
- **Domains**: Knowledge
- **Pantheon**: Forgotten Realms
- **Symbol**: Blank scroll