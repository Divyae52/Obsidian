---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/forgotten-realms
- domain/nature
aliases: ["Silvanus"]
---
# Silvanus
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral
- **Domains**: Nature
- **Pantheon**: Forgotten Realms
- **Symbol**: Oak leaf