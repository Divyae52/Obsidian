---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/knowledge
aliases: ["Oghma"]
---
# Oghma
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Good
- **Domains**: Knowledge
- **Pantheon**: Celtic
- **Symbol**: Unfurled scroll