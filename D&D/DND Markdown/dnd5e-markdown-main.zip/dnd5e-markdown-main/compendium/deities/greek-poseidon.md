---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/tempest
aliases: ["Poseidon"]
---
# Poseidon
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Neutral
- **Domains**: Tempest
- **Pantheon**: Greek
- **Symbol**: Trident