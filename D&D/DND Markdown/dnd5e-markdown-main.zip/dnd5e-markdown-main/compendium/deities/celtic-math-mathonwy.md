---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/arcana
- domain/knowledge
aliases: ["Math Mathonwy"]
---
# Math Mathonwy
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Evil
- **Domains**: Knowledge, Arcana
- **Pantheon**: Celtic
- **Symbol**: Staff