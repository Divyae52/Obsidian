---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/life
aliases: ["Brigantia"]
---
# Brigantia
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Good
- **Domains**: Life
- **Pantheon**: Celtic
- **Symbol**: Footbridge