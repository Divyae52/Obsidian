---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/greek
- domain/arcana
- domain/knowledge
- domain/trickery
aliases: ["Hecate"]
---
# Hecate
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Evil
- **Domains**: Knowledge, Trickery, Arcana
- **Pantheon**: Greek
- **Symbol**: Setting moon