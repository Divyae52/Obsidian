---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/celtic
- domain/nature
- domain/trickery
aliases: ["The Daghdha"]
---
# The Daghdha
*Source: SRD / Basic Rules* 

- **Alignment**: Chaotic Good
- **Domains**: Nature, Trickery
- **Pantheon**: Celtic
- **Symbol**: Bubbling cauldron or shield