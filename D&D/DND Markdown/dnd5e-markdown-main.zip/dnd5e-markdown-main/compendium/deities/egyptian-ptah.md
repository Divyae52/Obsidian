---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/knowledge
aliases: ["Ptah"]
---
# Ptah
*Source: SRD / Basic Rules* 

- **Alignment**: Lawful Neutral
- **Domains**: Knowledge
- **Pantheon**: Egyptian
- **Symbol**: Bull