---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/life
- domain/light
aliases: ["Hathor"]
---
# Hathor
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Good
- **Domains**: Life, Light
- **Pantheon**: Egyptian
- **Symbol**: Horned cow's head with lunar disk