---
obsidianUIMode: preview
cssclasses: json5e-deity
tags:
- compendium/src/5e/phb
- deity/egyptian
- domain/trickery
aliases: ["Apep"]
---
# Apep
*Source: SRD / Basic Rules* 

- **Alignment**: Neutral Evil
- **Domains**: Trickery
- **Pantheon**: Egyptian
- **Symbol**: Flaming snake