---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/attunement/required
- item/rarity/uncommon
- item/tier/major
- item/wondrous
aliases: ["Brooch of Shielding"]
---
# Brooch of Shielding
*Wondrous Item, major, uncommon (requires attunement)*  

- **Properties**: Requires Attunement
- **Cost**: ⏤
- **Weight**: ⏤

While wearing this brooch, you have resistance to force damage, and you have immunity to damage from the [magic missile](compendium/spells/magic-missile.md) spell.

*Source: SRD / Basic Rules*