---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Blanket"]
---
# Blanket
*Adventuring Gear*  

- **Cost**: 5 sp
- **Weight**: 3.0 lbs.

*Source: SRD / Basic Rules*