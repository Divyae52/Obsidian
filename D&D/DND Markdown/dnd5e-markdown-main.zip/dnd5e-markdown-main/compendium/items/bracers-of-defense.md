---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/attunement/required
- item/rarity/rare
- item/tier/major
- item/wondrous
aliases: ["Bracers of Defense"]
---
# Bracers of Defense
*Wondrous Item, major, rare (requires attunement)*  

- **Properties**: Requires Attunement
- **Cost**: ⏤
- **Weight**: ⏤

While wearing these bracers, you gain a +2 bonus to AC if you are wearing no armor and using no shield.

*Source: SRD / Basic Rules*