---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/rarity/rare
- item/tier/major
- item/wondrous
aliases: ["Bowl of Commanding Water Elementals"]
---
# Bowl of Commanding Water Elementals
*Wondrous Item, major, rare*  

- **Cost**: ⏤
- **Weight**: 3.0 lbs.

While this bowl is filled with water, you can use an action to speak the bowl's command word and summon a [water elemental](compendium/bestiary/elemental/water-elemental.md), as if you had cast the [conjure elemental](compendium/spells/conjure-elemental.md) spell. The bowl can't be used this way again until the next dawn.

The bowl is about 1 foot in diameter and half as deep. It weighs 3 pounds and holds about 3 gallons.

*Source: SRD / Basic Rules*