---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Bedroll"]
---
# Bedroll
*Adventuring Gear*  

- **Cost**: 1 gp
- **Weight**: 7.0 lbs.

*Source: SRD / Basic Rules*