---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/weapon/ammunition
aliases: ["Blowgun Needle"]
---
# Blowgun Needle
*Ammunition*  

- **Cost**: 2 cp
- **Weight**: 0.02 lbs.

*Source: SRD / Basic Rules*