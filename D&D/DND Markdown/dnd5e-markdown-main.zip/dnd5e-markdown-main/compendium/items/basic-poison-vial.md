---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear/poison
- item/property/poison
aliases: ["Basic Poison (vial)"]
---
# Basic Poison (vial)
*Adventuring Gear, poison*  

- **Properties**: Poison
- **Cost**: 100 gp
- **Weight**: ⏤

You can use the poison in this vial to coat one slashing or piercing weapon or up to three pieces of ammunition. Applying the poison takes an action. A creature hit by the poisoned weapon or ammunition must make a DC 10 Constitution saving throw or take `1d4` poison damage. Once applied, the poison retains potency for 1 minute before drying.

*Source: SRD / Basic Rules*