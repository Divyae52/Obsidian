---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Antitoxin (vial)"]
---
# Antitoxin (vial)
*Adventuring Gear*  

- **Cost**: 50 gp
- **Weight**: ⏤

A creature that drinks this vial of liquid gains advantage on saving throws against poison for 1 hour. It confers no benefit to undead or constructs.

*Source: SRD / Basic Rules*