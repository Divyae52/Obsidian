---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Bucket"]
---
# Bucket
*Adventuring Gear*  

- **Cost**: 5 cp
- **Weight**: 2.0 lbs.

A bucket holds 3 gallons of liquid or ½ cubic foot of solids.

*Source: SRD / Basic Rules*