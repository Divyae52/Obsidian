---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear/artisans-tools
aliases: ["Calligrapher's Supplies"]
---
# Calligrapher's Supplies
*Artisan's Tools*  

- **Cost**: 10 gp
- **Weight**: 5.0 lbs.

*Source: SRD / Basic Rules*