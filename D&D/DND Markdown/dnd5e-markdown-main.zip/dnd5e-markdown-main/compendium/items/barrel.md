---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Barrel"]
---
# Barrel
*Adventuring Gear*  

- **Cost**: 2 gp
- **Weight**: 70.0 lbs.

A barrel can hold 40 gallons of liquid or 4 cubic feet of solids.

*Source: SRD / Basic Rules*