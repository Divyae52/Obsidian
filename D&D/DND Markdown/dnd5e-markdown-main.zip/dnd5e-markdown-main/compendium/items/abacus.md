---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Abacus"]
---
# Abacus
*Adventuring Gear*  

- **Cost**: 2 gp
- **Weight**: 2.0 lbs.

*Source: SRD / Basic Rules*