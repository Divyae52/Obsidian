---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/gear/poison
- item/property/poison
aliases: ["Burnt Othur Fumes"]
---
# Burnt Othur Fumes
*Adventuring Gear, poison*  

- **Properties**: Poison
- **Cost**: 500 gp
- **Weight**: ⏤

A creature subjected to this poison must succeed on a DC 13 Constitution saving throw or take 10 (`3d6`) poison damage, and must repeat the saving throw at the start of each of its turns. On each successive failed save, the character takes 3 (`1d6`) poison damage. After three successful saves, the poison ends.

*Source: SRD / Basic Rules*