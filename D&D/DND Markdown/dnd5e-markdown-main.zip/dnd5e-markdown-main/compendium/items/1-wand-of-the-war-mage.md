---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/attunement/required
- item/rarity/uncommon
- item/tier/major
- item/wondrous/wand
aliases: ["+1 Wand of the War Mage"]
---
# +1 Wand of the War Mage
*Wand, major, uncommon (requires attunement by a spellcaster)*  

- **Properties**: Requires Attunement
- **Cost**: ⏤
- **Weight**: 1.0 lbs.

While you are holding this wand, you gain a +1 bonus to spell attack rolls. In addition, you ignore half cover when making a spell attack.

*Source: SRD / Basic Rules*