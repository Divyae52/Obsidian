---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/attunement/required
- item/rarity/uncommon
- item/tier/major
- item/wondrous
aliases: ["Bracers of Archery"]
---
# Bracers of Archery
*Wondrous Item, major, uncommon (requires attunement)*  

- **Properties**: Requires Attunement
- **Cost**: ⏤
- **Weight**: ⏤

While wearing these bracers, you have proficiency with the longbow and shortbow, and you gain a +2 bonus to damage rolls on ranged attacks made with such weapons.

*Source: SRD / Basic Rules*