---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/attunement/required
- item/rarity/legendary
- item/tier/major
- item/wondrous
aliases: ["Belt of Storm Giant Strength"]
---
# Belt of Storm Giant Strength
*Wondrous Item, major, legendary (requires attunement)*  

- **Properties**: Requires Attunement
- **Cost**: ⏤
- **Weight**: ⏤

While wearing this belt, your Strength score changes to 29. The item has no effect on you if your Strength without the belt is equal to or greater than the belt's score.

*Source: SRD / Basic Rules*