---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Bell"]
---
# Bell
*Adventuring Gear*  

- **Cost**: 1 gp
- **Weight**: ⏤

*Source: SRD / Basic Rules*