---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Backpack"]
---
# Backpack
*Adventuring Gear*  

- **Cost**: 2 gp
- **Weight**: 5.0 lbs.

A backpack can hold one cubic foot or 30 pounds of gear. You can also strap items, such as a bedroll or a coil of rope, to the outside of a backpack.

*Source: SRD / Basic Rules*