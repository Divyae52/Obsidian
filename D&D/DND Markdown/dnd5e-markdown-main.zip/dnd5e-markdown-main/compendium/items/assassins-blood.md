---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/gear/poison
- item/property/poison
aliases: ["Assassin's Blood"]
---
# Assassin's Blood
*Adventuring Gear, poison*  

- **Properties**: Poison
- **Cost**: 150 gp
- **Weight**: ⏤

A creature subjected to this poison must make a DC 10 Constitution saving throw. On a failed save, it takes 6 (`1d12`) poison damage and is [poisoned](rules/conditions.md#poisoned) for 24 hours. On a successful save, the creature takes half damage and isn't [poisoned](rules/conditions.md#poisoned).

*Source: SRD / Basic Rules*