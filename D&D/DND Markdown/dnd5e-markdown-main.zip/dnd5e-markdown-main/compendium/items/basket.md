---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Basket"]
---
# Basket
*Adventuring Gear*  

- **Cost**: 4 sp
- **Weight**: 2.0 lbs.

A basket holds 2 cubic feet or 40 pounds of gear.

*Source: SRD / Basic Rules*