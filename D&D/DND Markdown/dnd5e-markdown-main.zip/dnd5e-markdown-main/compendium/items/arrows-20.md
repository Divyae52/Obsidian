---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/weapon/ammunition
aliases: ["Arrows (20)"]
---
# Arrows (20)
*Ammunition*  

- **Cost**: 1 gp
- **Weight**: 1.0 lbs.

*Source: SRD / Basic Rules*