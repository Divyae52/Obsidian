---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/attunement/required
- item/rarity/rare
- item/tier/major
- item/wondrous
aliases: ["Boots of Levitation"]
---
# Boots of Levitation
*Wondrous Item, major, rare (requires attunement)*  

- **Properties**: Requires Attunement
- **Cost**: ⏤
- **Weight**: ⏤

While you wear these boots, you can use an action to cast the [levitate](compendium/spells/levitate.md) spell on yourself at will.

*Source: SRD / Basic Rules*