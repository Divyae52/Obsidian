---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/attunement/required
- item/rarity/uncommon
- item/tier/major
- item/wondrous
aliases: ["Amulet of Proof against Detection and Location"]
---
# Amulet of Proof against Detection and Location
*Wondrous Item, major, uncommon (requires attunement)*  

- **Properties**: Requires Attunement
- **Cost**: ⏤
- **Weight**: 1.0 lbs.

While wearing this amulet, you are hidden from divination magic. You can't be targeted by such magic or perceived through magical scrying sensors.

*Source: SRD / Basic Rules*