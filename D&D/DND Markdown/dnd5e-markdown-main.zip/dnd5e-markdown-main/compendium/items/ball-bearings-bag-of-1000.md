---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Ball Bearings (bag of 1,000)"]
---
# Ball Bearings (bag of 1,000)
*Adventuring Gear*  

- **Cost**: 1 gp
- **Weight**: 2.0 lbs.

As an action, you can spill these tiny metal balls from their pouch to cover a level area 10 feet square. A creature moving across the covered area must succeed on a DC 10 Dexterity saving throw or fall [prone](rules/conditions.md#prone). A creature moving through the area at half speed doesn't need to make the saving throw.

*Source: SRD / Basic Rules*