---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/rarity/rare
- item/tier/major
- item/wondrous
aliases: ["Brazier of Commanding Fire Elementals"]
---
# Brazier of Commanding Fire Elementals
*Wondrous Item, major, rare*  

- **Cost**: ⏤
- **Weight**: 5.0 lbs.

While a fire burns in this brass brazier, you can use an action to speak the brazier's command word and summon a [fire elemental](compendium/bestiary/elemental/fire-elemental.md), as if you had cast the [conjure elemental](compendium/spells/conjure-elemental.md) spell. The brazier can't be used this way again until the next dawn.

The brazier weighs 5 pounds.

*Source: SRD / Basic Rules*