---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Book"]
---
# Book
*Adventuring Gear*  

- **Cost**: 25 gp
- **Weight**: 5.0 lbs.

A book might contain poetry, historical accounts, information pertaining to a particular field of lore, diagrams and notes on gnomish contraptions, or just about anything else that can be represented using text or pictures. A book of spells is a [spellbook](compendium/items/spellbook.md).

*Source: SRD / Basic Rules*