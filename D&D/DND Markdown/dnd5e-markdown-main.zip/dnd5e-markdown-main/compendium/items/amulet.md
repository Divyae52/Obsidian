---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear/spellcasting-focus
aliases: ["Amulet"]
---
# Amulet
*Spellcasting Focus*  

- **Cost**: 5 gp
- **Weight**: 1.0 lbs.

*Source: SRD / Basic Rules*