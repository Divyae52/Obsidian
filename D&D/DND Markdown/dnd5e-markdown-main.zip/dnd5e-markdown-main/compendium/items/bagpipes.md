---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear/instrument
aliases: ["Bagpipes"]
---
# Bagpipes
*Instrument*  

- **Cost**: 30 gp
- **Weight**: 6.0 lbs.

*Source: SRD / Basic Rules*