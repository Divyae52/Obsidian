---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/armor/shield
- item/attunement/required
- item/rarity/rare
- item/tier/major
aliases: ["Arrow-Catching Shield"]
---
# Arrow-Catching Shield
*Shield, major, rare (requires attunement)*  

- **Armor Class**: 2
- **Properties**: Requires Attunement
- **Cost**: ⏤
- **Weight**: 6.0 lbs.

You gain a +2 bonus to AC against ranged attacks while you wield this shield. This bonus is in addition to the shield's normal bonus to AC. In addition, whenever an attacker makes a ranged attack against a target within 5 feet of you, you can use your reaction to become the target of the attack instead.

*Source: SRD / Basic Rules*