---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/attunement/required
- item/rarity/uncommon
- item/tier/major
- item/wondrous
aliases: ["Boots of Striding and Springing"]
---
# Boots of Striding and Springing
*Wondrous Item, major, uncommon (requires attunement)*  

- **Properties**: Requires Attunement
- **Cost**: ⏤
- **Weight**: ⏤

While you wear these boots, your walking speed becomes 30 feet, unless your walking speed is higher, and your speed isn't reduced if you are encumbered or wearing heavy armor. In addition, you can jump three times the normal distance, though you can't jump farther than your remaining movement would allow.

*Source: SRD / Basic Rules*