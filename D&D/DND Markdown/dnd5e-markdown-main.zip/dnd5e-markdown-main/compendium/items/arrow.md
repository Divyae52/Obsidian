---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/weapon/ammunition
aliases: ["Arrow"]
---
# Arrow
*Ammunition*  

- **Cost**: 5 cp
- **Weight**: 0.05 lbs.

*Source: SRD / Basic Rules*