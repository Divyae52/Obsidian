---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Ball Bearing"]
---
# Ball Bearing
*Adventuring Gear*  

- **Cost**: ⏤
- **Weight**: 0.002 lbs.

Most commonly found inside a [bag of ball bearings](compendium/items/ball-bearings-bag-of-1000.md).

*Source: SRD / Basic Rules*