---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear/tack-and-harness
aliases: ["Bit and bridle"]
---
# Bit and bridle
*Tack and Harness*  

- **Cost**: 2 gp
- **Weight**: 1.0 lbs.

*Source: SRD / Basic Rules*