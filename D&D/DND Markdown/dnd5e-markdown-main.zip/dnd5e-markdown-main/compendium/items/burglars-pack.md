---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Burglar's Pack"]
---
# Burglar's Pack
*Adventuring Gear*  

- **Cost**: 16 gp
- **Weight**: 44.5 lbs.

Includes:

- a [backpack](compendium/items/backpack.md)  
- a [bag of 1,000 ball bearings](compendium/items/ball-bearings-bag-of-1000.md)  
- 10 feet of string  
- a [bell](compendium/items/bell.md)  
- 5 [candles](compendium/items/candle.md)  
- a [crowbar](compendium/items/crowbar.md)  
- a [hammer](compendium/items/hammer.md)  
- 10 [pitons](compendium/items/piton.md)  
- a [hooded lantern](compendium/items/hooded-lantern.md)  
- 2 [flasks of oil](compendium/items/oil-flask.md)  
- 5 days [rations](compendium/items/rations-1-day.md)  
- a [tinderbox](compendium/items/tinderbox.md)  
- a [waterskin](compendium/items/waterskin.md)  
- [50 feet of hempen rope](compendium/items/hempen-rope-50-feet.md)  

*Source: SRD / Basic Rules*