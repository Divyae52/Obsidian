---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear/food-and-drink
aliases: ["Ale (Mug)"]
---
# Ale (Mug)
*Food and Drink*  

- **Cost**: 4 cp
- **Weight**: ⏤

*Source: SRD / Basic Rules*