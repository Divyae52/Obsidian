---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear/mount
aliases: ["Camel"]
---
# Camel
*Mount*  

- **Cost**: 50 gp
- **Weight**: ⏤

*Source: SRD / Basic Rules*