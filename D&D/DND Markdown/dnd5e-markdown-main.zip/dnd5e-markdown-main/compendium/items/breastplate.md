---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/armor/medium
aliases: ["Breastplate"]
---
# Breastplate
*Medium Armor*  

- **Armor Class**: 14 + DEX (max of +2)
- **Cost**: 400 gp
- **Weight**: 20.0 lbs.

This armor consists of a fitted metal chest piece worn with supple leather. Although it leaves the legs and arms relatively unprotected, this armor provides good protection for the wearer's vital organs while leaving the wearer relatively unencumbered.

*Source: SRD / Basic Rules*