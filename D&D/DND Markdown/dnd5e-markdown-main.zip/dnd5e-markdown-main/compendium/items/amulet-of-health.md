---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/attunement/required
- item/rarity/rare
- item/tier/major
- item/wondrous
aliases: ["Amulet of Health"]
---
# Amulet of Health
*Wondrous Item, major, rare (requires attunement)*  

- **Properties**: Requires Attunement
- **Cost**: ⏤
- **Weight**: 1.0 lbs.

Your Constitution score is 19 while you wear this amulet. It has no effect on you if your Constitution score is already 19 or higher without it.

*Source: SRD / Basic Rules*