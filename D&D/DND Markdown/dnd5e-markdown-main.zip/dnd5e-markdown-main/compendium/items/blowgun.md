---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/property/ammunition
- item/property/loading
- item/property/martial
- item/weapon/martial/ranged
aliases: ["Blowgun"]
---
# Blowgun
*Ranged Weapon*  

- **Damage**: 1 P
- **Range**: 25/100
- **Properties**: Ammunition, Loading, Martial
- **Cost**: 10 gp
- **Weight**: 1.0 lbs.

*Source: SRD / Basic Rules*