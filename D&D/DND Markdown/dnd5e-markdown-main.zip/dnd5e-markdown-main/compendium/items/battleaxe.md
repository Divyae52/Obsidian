---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/property/martial
- item/property/versatile
- item/weapon/martial/melee
aliases: ["Battleaxe"]
---
# Battleaxe
*Melee Weapon*  

- **Damage**:
  - One-handed: 1d8 S
  - Two-handed: 1d10 S
- **Properties**: Martial, Versatile
- **Cost**: 10 gp
- **Weight**: 4.0 lbs.

*Source: SRD / Basic Rules*