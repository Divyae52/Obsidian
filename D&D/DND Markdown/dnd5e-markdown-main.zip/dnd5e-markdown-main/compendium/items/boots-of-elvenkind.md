---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/dmg
- item/rarity/uncommon
- item/tier/major
- item/wondrous
aliases: ["Boots of Elvenkind"]
---
# Boots of Elvenkind
*Wondrous Item, major, uncommon*  

- **Cost**: ⏤
- **Weight**: ⏤

While you wear these boots, your steps make no sound, regardless of the surface you are moving across. You also have advantage on Dexterity ([Stealth](rules/skills.md#Stealth)) checks that rely on moving silently.

*Source: SRD / Basic Rules*