---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Bullseye Lantern"]
---
# Bullseye Lantern
*Adventuring Gear*  

- **Cost**: 10 gp
- **Weight**: 2.0 lbs.

A bullseye lantern casts bright light in a 60-foot cone and dim light for an additional 60 feet. Once lit, it burns for 6 hours on a flask (1 pint) of oil.

*Source: SRD / Basic Rules*