---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear/food-and-drink
aliases: ["Ale (Gallon)"]
---
# Ale (Gallon)
*Food and Drink*  

- **Cost**: 2 sp
- **Weight**: ⏤

*Source: SRD / Basic Rules*