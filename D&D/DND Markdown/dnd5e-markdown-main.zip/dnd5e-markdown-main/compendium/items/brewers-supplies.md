---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear/artisans-tools
aliases: ["Brewer's Supplies"]
---
# Brewer's Supplies
*Artisan's Tools*  

- **Cost**: 20 gp
- **Weight**: 9.0 lbs.

*Source: SRD / Basic Rules*