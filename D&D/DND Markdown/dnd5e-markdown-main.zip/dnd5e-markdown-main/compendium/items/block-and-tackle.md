---
obsidianUIMode: preview
cssclasses: json5e-item
tags:
- compendium/src/5e/phb
- item/gear
aliases: ["Block and Tackle"]
---
# Block and Tackle
*Adventuring Gear*  

- **Cost**: 1 gp
- **Weight**: 5.0 lbs.

A set of pulleys with a cable threaded through them and a hook to attach to objects, a block and tackle allows you to hoist up to four times the weight you can normally lift.

*Source: SRD / Basic Rules*