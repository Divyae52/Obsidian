---
obsidianUIMode: preview
cssclasses: json5e-feat
tags:
- compendium/src/5e/phb
aliases: ["Grappler"]
---
# Grappler
*Source: SRD / Basic Rules*  

***Prerequisites*** Strength 13 or higher

You've developed the skills necessary to hold your own in close-quarters grappling. You gain the following benefits:

- You have advantage on attack rolls against a creature you are grappling.  
- You can use your action to try to pin a creature [grappled](rules/conditions.md#grappled) by you. To do so, make another grapple check. If you succeed, you and the creature are both [restrained](rules/conditions.md#restrained) until the grapple ends.