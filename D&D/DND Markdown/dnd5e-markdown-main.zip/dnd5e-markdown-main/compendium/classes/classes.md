---
obsidianUIMode: preview
cssclasses: json5e-note
---
# Index of Classes

- [Barbarian: Path of the Berserker](barbarian-path-of-the-berserker.md)
- [Barbarian](barbarian.md)
- [Bard: College of Lore](bard-college-of-lore.md)
- [Bard](bard.md)
- [Cleric: Life Domain](cleric-life-domain.md)
- [Cleric](cleric.md)
- [Druid: Circle of the Land](druid-circle-of-the-land.md)
- [Druid](druid.md)
- [Fighter: Champion](fighter-champion.md)
- [Fighter](fighter.md)
- [Monk: Way of the Open Hand](monk-way-of-the-open-hand.md)
- [Monk](monk.md)
- [Paladin: Oath of Devotion](paladin-oath-of-devotion.md)
- [Paladin](paladin.md)
- [Ranger: Hunter](ranger-hunter.md)
- [Ranger](ranger.md)
- [Rogue: Thief](rogue-thief.md)
- [Rogue](rogue.md)
- [Sorcerer: Draconic Bloodline](sorcerer-draconic-bloodline.md)
- [Sorcerer](sorcerer.md)
- [Warlock: The Fiend](warlock-the-fiend.md)
- [Warlock](warlock.md)
- [Wizard: School of Evocation](wizard-school-of-evocation.md)
- [Wizard](wizard.md)
